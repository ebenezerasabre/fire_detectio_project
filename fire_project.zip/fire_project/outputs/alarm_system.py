
# Import necessary modules
import os
import sys

# Define functions
def check_flag_file():
    """
    Checks if the flag file exists and contains "true" or "false".
    Returns True if fire is detected, False otherwise.
    """
    # Check if flag file exists
    if not os.path.exists("outputs/fire_detected.txt"):
        print("Error: Flag file not found.")
        sys.exit()
    
    # Read flag file
    with open("outputs/fire_detected.txt", "r") as f:
        flag = f.read().strip().lower()
    
    # Check flag value
    if flag == "true":
        return True
    elif flag == "false":
        return False
    else:
        print("Error: Invalid flag value.")
        sys.exit()

def activate_alarm():
    """
    Simulates activating a fire alarm by printing a message to the terminal.
    """
    print("ALARM: Fire detected!")

def send_email():
    """
    Simulates sending an email notification by printing the email subject and body to the terminal.
    """
    print("Email Subject: Fire Alarm Notification")
    print("Email Body: A fire has been detected. Please evacuate the building immediately.")

# Main function
def main():
    # Check flag file
    fire_detected = check_flag_file()

    # If fire is detected, activate alarm and send email
    if fire_detected:
        activate_alarm()
        send_email()
    else:
        print("No fire detected.")

# Execute main function
if __name__ == "__main__":
    main()