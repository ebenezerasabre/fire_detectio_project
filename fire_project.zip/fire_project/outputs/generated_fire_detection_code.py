
# Import necessary libraries
import os
import cv2
import numpy as np

# Function to load images from a directory
def load_images(directory):
    """
    Loads images from a specified directory and returns the image data and filenames.

    Parameters:
        directory (str): Path to the directory containing images.

    Returns:
        images (list): List of image data.
        filenames (list): List of image filenames.
    """
    images = []
    filenames = []

    # Loop through all files in the directory
    for file in os.listdir(directory):
        # Check if the file has a valid image extension
        if file.endswith(".png") or file.endswith(".jpg") or file.endswith(".jpeg"):
            # Read the image and append to the list
            image = cv2.imread(os.path.join(directory, file))
            images.append(image)
            # Append the filename to the list
            filenames.append(file)

    return images, filenames

# Function to detect fire regions in an image
def detect_fire(image):
    """
    Detects fire-like regions in an image based on color thresholds using the HSV color space.

    Parameters:
        image (numpy.ndarray): Image data.

    Returns:
        fire_mask (numpy.ndarray): Binary mask of fire-like regions.
        confidence_score (float): Percentage of fire-like pixels in the image.
    """
    # Convert the image to HSV color space
    hsv_image = cv2.cvtColor(image, cv2.COLOR_BGR2HSV)

    # Define lower and upper thresholds for fire-like colors in HSV color space
    lower_threshold = np.array([0, 50, 50])
    upper_threshold = np.array([10, 255, 255])

    # Create a mask for fire-like colors
    fire_mask = cv2.inRange(hsv_image, lower_threshold, upper_threshold)

    # Calculate the percentage of fire-like pixels in the image
    confidence_score = np.count_nonzero(fire_mask) / (image.shape[0] * image.shape[1]) * 100

    return fire_mask, confidence_score

# Function to save the processed output image
def save_output_image(image, fire_mask, filename):
    """
    Saves the processed output image with fire regions outlined in red to the "outputs/" directory.

    Parameters:
        image (numpy.ndarray): Original image data.
        fire_mask (numpy.ndarray): Binary mask of fire-like regions.
        filename (str): Original image filename.
    """
    # Create a copy of the original image
    output_image = image.copy()

    # Create a red outline for fire-like regions
    output_image[fire_mask == 255] = [0, 0, 255]

    # Save the output image to the "outputs/" directory
    cv2.imwrite("outputs/fire_detected_" + filename, output_image)

# Function to write fire detection status to the file
def write_status(status):
    """
    Writes the fire detection status to the "outputs/fire_detected.txt" file.

    Parameters:
        status (bool): Fire detection status.
    """
    # Create the "outputs/" directory if it doesn't exist
    if not os.path.exists("outputs/"):
        os.makedirs("outputs/")

    # Write the status to the file
    with open("outputs/fire_detected.txt", "w") as file:
        file.write(str(status))

# Main function
def main():
    # Load images from the "images/" directory
    images, filenames = load_images("images/")

    # Initialize a list to store the confidence scores
    confidence_scores = []

    # Loop through all images
    for image, filename in zip(images, filenames):
        try:
            # Detect fire regions in the image
            fire_mask, confidence_score = detect_fire(image)

            # Save the processed output image
            save_output_image(image, fire_mask, filename)

            # Append the confidence score to the list
            confidence_scores.append(confidence_score)

            # Print the confidence score in the terminal
            print("Fire detection confidence score for " + filename + ": " + str(confidence_score) + "%")
        except:
            # Skip the file if it cannot be loaded as a valid image
            print("Error loading " + filename + ". Skipping...")

    # Calculate the overall fire detection status
    if any(score > 0 for score in confidence_scores):
        status = True
    else:
        status = False

    # Write the fire detection status to the file
    write_status(status)

    # Print a summary of fire detection results in the terminal
    print("Fire detection status: " + str(status))
    print("Total images processed: " + str(len(images)))
    print("Images with fire detected: " + str(sum(score > 0 for score in confidence_scores)))
    print("Images with no fire detected: " + str(sum(score == 0 for score in confidence_scores)))

# Call the main function
if __name__ == "__main__":
    main()