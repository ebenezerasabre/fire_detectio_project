import cv2
import os

import matplotlib.pyplot as plt

def preprocess_image(image_path):
    """
    Preprocess the image for analysis.
    """
    image = cv2.imread(image_path)
    resized = cv2.resize(image, (224, 224))
    return resized


def preprocess_imagex(image_path):
    """
    Preprocess the image for analysis.
    Saves the processed image with 'pr' added to the filename.
    """
    # Check if the file exists
    if not os.path.exists(image_path):
        raise FileNotFoundError(f"Image not found: {image_path}")

    # Read and resize the image
    image = cv2.imread(image_path)
    if image is None:
        raise ValueError(f"Unable to read the image file: {image_path}")
    resized = cv2.resize(image, (224, 224))

    # Save the processed image with 'pr' added to the filename
    directory, filename = os.path.split(image_path)
    name, ext = os.path.splitext(filename)
    processed_path = os.path.join(directory, f"{name}_pr{ext}")
    cv2.imwrite(processed_path, resized)

    # print(f"Processed image saved to: {processed_path}")
    # return resized, processed_path
    return resized



def display_image(image):
    """
    Display an image using matplotlib.
    """
    plt.imshow(cv2.cvtColor(image, cv2.COLOR_BGR2RGB))
    plt.axis("off")
    plt.show()

# # Correct path to the image
image_path = "../images/image.png"  # Adjusted relative path

# # Test image preprocessing and display
if os.path.exists(image_path):
    image_prc = preprocess_imagex(image_path)
    display_image(image_prc)
else:
    print(f"File not found: {image_path}")







