import os
import openai
import cv2
import matplotlib.pyplot as plt
import numpy as np
from PIL import Image
from langchain_openai import OpenAI
from langchain.prompts import PromptTemplate
from langchain.schema.runnable import RunnableSequence
import key_params
from utils.fire_detect_utils import *

# Set your OpenAI API key
# os.environ["OPENAI_API_KEY"] = key_params.openai_api_key

# Initialize the OpenAI LLM
llm_generate = OpenAI(temperature=0, max_tokens=1500, openai_api_key=key_params.openai_api_fire_key)
llm_review = OpenAI(temperature=0, max_tokens=1500, openai_api_key=key_params.openai_api_fire_key)
llm_alarm = OpenAI(temperature=0, max_tokens=1500, openai_api_key=key_params.openai_api_fire_key)


fire_detection_prompt = """
You are an expert in computer vision. Write Python code to detect fire in images using OpenCV. The system should process all images in a specified directory and identify regions with fire-like colors. Ensure the code follows these requirements:

1. Read all images from the "images/" directory. Only process files with extensions like `.png`, `.jpg`, or `.jpeg`.
2. Detect fire-like regions in each image based on color thresholds using the HSV color space.
3. Return both the image data and filenames when loading images from the directory.
4. Calculate and display the fire detection confidence score (percentage of fire-like pixels) in the terminal for each image.
5. Save each processed image with fire regions visually outlined in red to the "outputs/" directory. Use the naming format `fire_detected_<original_image_name>.png`.
   - Overlay the fire mask on the original image, with fire-like regions outlined in red.
6. After processing all images, write the fire detection status to the `outputs/fire_detected.txt` file:
   - If any image has a `confidence_score > 0`, write `true` to the file.
   - Otherwise, write `false`.
7. Modularize the code into functions for tasks like:
   - Loading images from a directory.
   - Detecting fire regions in an image.
   - Saving the processed output image.
   - Writing fire detection status to the file.
8. Ensure the system creates the "outputs/" directory automatically if it doesn’t exist.
9. Include error handling to skip files that cannot be loaded as valid images.
10. Write efficient, well-commented code that adheres to Pythonic best practices.

The system should process all images sequentially, save processed images with outlined fire regions, write the fire detection status to `outputs/fire_detected.txt`, and print a summary of fire detection results in the terminal once completed.
"""


code_review_prompt = """
You are an expert Python developer and code reviewer. Review the following Python code to ensure it meets the specified requirements:

1. Adheres to Python best practices (modularization, comments, readability).
2. Contains no errors or vulnerabilities.
3. Implements all the requested functionality and requirements.
4. Is efficient and optimized for performance.
5. Handles errors gracefully.

Specifically, check if:
- The function for loading images returns both the image data and filenames.
- File handling correctly processes valid images only.
- The main logic correctly associates images with their respective filenames.
- The processed output images visually highlight fire-like regions in red using the fire mask overlay.

If any issues are found, suggest improvements or corrections. If the code is perfect, state "The code is well-structured and meets all requirements."

Code to review:
"""


# Alarm detection prompt
alarm_detection_prompt = """
You are an expert in Python systems programming. Write a simple Python script for a fire alarm detection system that performs the following tasks:

1. Checks if a fire has been detected by reading a flag file (e.g., `outputs/fire_detected.txt`). The flag file should contain "true" if fire is detected and "False" otherwise.
2. If fire is detected:
   - Simulate activating a fire alarm by printing a message to the terminal (e.g., "ALARM: Fire detected!").
   - Simulate sending an email notification by printing the email subject and body to the terminal.
3. Modularize the code into functions:
   - A function to check the flag file.
   - A function to simulate the alarm sound by printing to the terminal.
   - A function to simulate sending an email by printing the email subject and body to the terminal.
4. Include proper error handling:
   - If the flag file is missing, print an appropriate error message and exit.
   - If any other error occurs, provide a clear message.
5. Ensure the code is efficient, well-commented, and adheres to Pythonic best practices.

The system should run as a standalone Python script and execute the appropriate actions if fire is detected.
"""


# Create the prompt templates
generate_prompt = PromptTemplate(input_variables=[], template=fire_detection_prompt)
review_prompt = PromptTemplate(input_variables=["code"], template=code_review_prompt)
alarm_generate_prompt = PromptTemplate(input_variables=[], template=alarm_detection_prompt)


# Create the RunnableSequences
chain_generate = generate_prompt | llm_generate
chain_review = review_prompt | llm_review
alarm_chain_generate = alarm_generate_prompt | llm_alarm


# Generate the code
generated_code = chain_generate.invoke({})
print("Generated Python Code:")
print(generated_code)

# Review the code
review_feedback = chain_review.invoke({"code": generated_code})
print("\nCode Review Feedback:")
print(review_feedback)

# Decision to execute the code
if "The code is well-structured and meets all requirements" in review_feedback:
    # Save and execute fire detection code
    os.makedirs("outputs", exist_ok=True)
    with open("outputs/generated_fire_detection_code.py", "w") as file:
        file.write(generated_code)
    exec(generated_code)

    # After Fire Detection, Generate Alarm System
    print("\nGenerating Alarm Detection System...")
    alarm_generated_code = alarm_chain_generate.invoke({})
    print("Generated Alarm Detection Code:")
    print(alarm_generated_code)

    # Save the alarm system code
    with open("outputs/alarm_system.py", "w") as file:
        file.write(alarm_generated_code)

    # Execute Alarm System
    print("Executing Alarm System...")
    exec(alarm_generated_code)
else:
    print("Fire detection code review failed. Fix the issues before proceeding.")



